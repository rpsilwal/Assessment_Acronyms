//
//  AppDelegate.h
//  Assessment_Acronyms
//
//  Created by Ranjan on 4/20/16.
//  Copyright © 2016 Ranjan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

